// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Who is making the Web standards?What is HTML?",
    answer: "All of the mentioned",
    options: [
      "HTML describes the structure of a webpage",
      " HTML is the standard markup language mainly used to create web pages",
      "HTML consists of a set of elements that helps the browser how to view the content",
      "All of the mentioned"
    ]
  },
    {
    numb: 2,
    question: "Which of the following CSS style property is used to specify an italic text?",
    answer: "font-style",
    options: [
       "style",
      "font",
      "font-style",
      "@font-face"
    ]
  },
    {
    numb: 3,
    question: "Which of the following is the default file extension of PHP files?",
    answer: ".php",
    options: [
      ".php",
      ".ph",
      ".ph",
       ".html"
    ]
  },
    {
    numb: 4,
    question: " PHP recognizes constructors by the name _________",
    answer: "function __construct()",
    options: [
      "function __construct()",
      "function _construct()",
      "classname()",
      "_construct()"
    ]
  },
    {
    numb: 5,
    question: "What does XML stand for?",
    answer: "eXtensible Markup Language",
    options: [
      "eXtensible Markup Language",
      "eXecutable Multiple Language",
      "eXTra Multi-Program Language",
      "eXamine Multiple Language"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];